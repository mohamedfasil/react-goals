# Reflektive Assignment

First install all the packages

```sh
npm install 
```

Or

```sh
yarn install 
```
Start the app

```sh
npm run start
```

Or

```sh
yarn run start
```

I've used React and simple callback between parent and child component to manage the state.


HTML/CSS Assignment I've done as part of this code base itself, please see CSSAsignment.js and CSSAsignment.less, 
